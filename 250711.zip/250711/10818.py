N=int(input())
num_list=[int(x) for x in input().split()]
num_list=sorted(num_list)
print(num_list[0],num_list[N-1])