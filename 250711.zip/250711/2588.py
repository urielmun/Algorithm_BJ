a=int(input())
b=int(input())

b_1=b%10
b_10=b%100-b_1
b_100=b-b_10-b_1

b_1=a*b_1
b_10=a*b_10
b_100=a*b_100

print(b_1)
print(b_10//10)
print(b_100//100)
print(b_1+b_10+b_100)
