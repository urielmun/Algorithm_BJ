A,B,C=map(int,input().split())
print(A+B+C)