sum_list=[]
while(True):
    try:
        A,B=map(int,input().split())
        sum=A+B
        sum_list.append(sum)
    except ValueError:
        break
    except NameError:
        break
    except EOFError:
        break


for sum in sum_list:
    print(sum)
