H,M=map(int,input().split())
M=M-45
if(M<0):
    H-=1
    M+=60
if(H>23): H-=24
if(H<0): H+=24
if(M>59): H-=60


print(H,M)