y=int(input())
print(y-2541+1998)