
sentence=input()
wordlist=sentence.split(" ")
print(len(wordlist))