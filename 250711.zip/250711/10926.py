name=input()
print(name+"??!")